
 Compiles for flash player 10.0 and up.
 
# Main files for compile: 
	
	
 * mvcExpress-helloWorld\src\helloWorld\Main.as
	
 * mvcExpress-ticTacToe\src\ticTacToe\Main.as
	
 * mvcExpress-modular\src\modularProject\modularSample\ModularSample.as
 * mvcExpress-modular\src\modularProject\modules\console\Console.as